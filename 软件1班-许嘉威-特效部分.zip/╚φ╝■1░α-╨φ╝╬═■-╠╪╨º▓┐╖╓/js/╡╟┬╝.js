/**
 * 函数：登录判定
 * 参数：账号、密码
 * 返回值：true/false
 */
var i = 3;//登录机会 
function logon(acc, pwd) {
    // console.log("进入for循环的第" + (3 - i) + "轮");
    // var result;
    //三次以内尝试验证登录
    if (acc == "peter" && pwd == "123"&& i>0) {
        // result = true;
        document.getElementById('hint').innerHTML = '成功登录！';
        location.href = './主页.html';//跳转主页
        //break;//强制跳出
    }
    else if(i <= 0) {//尝试三次
        document.getElementById('hint').innerHTML = '尝试三次登录失败，没有登录机会！';
    }
     else {
        i -= 1;//每次登录失败，登录机会减1
        document.getElementById('hint').innerHTML = '账号或密码错误，还剩下' + i + '次机会';
    }
}
    // return result;<----返回值
