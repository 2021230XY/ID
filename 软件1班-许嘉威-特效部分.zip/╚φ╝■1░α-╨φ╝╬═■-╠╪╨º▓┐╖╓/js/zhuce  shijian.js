onload = function () {
    //获取手机号输入框对象
    var phoneNum = document.getElementById("phoneNum");
    var pdsjh = document.getElementById("pdsjh");
    console.log("phoneNum:" + phoneNum);
    console.log("pdsjh:" + pdsjh);

    //添加事件onblur
    phoneNum.onblur = function () {
        //判定输入内容是否合法（是数字，并且长度为11位），并给予提示
        if (!isNaN(phoneNum.value) && phoneNum.value.length == 11) {
            pdsjh.innerHTML = "正确";
        } else {
            pdsjh.innerHTML = "输入错误"
        }
    }


    //通过id获取元素
    var pdyzm = document.getElementById("pdyzm");
    var verification = document.getElementById("verification");

    //添加元素的blur事件监听器
    verification.addEventListener("blur", inputVerification, false);
    function inputVerification() {
        if (verification.value == "92794") {
            pdyzm.innerHTML = "验证码正确"
        } else {
            pdyzm.innerHTML = "验证码错误"
        }
    }
}