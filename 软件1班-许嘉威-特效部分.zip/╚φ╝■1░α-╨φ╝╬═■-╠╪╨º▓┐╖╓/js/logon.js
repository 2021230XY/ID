/**
 * 函数：登录判定
 * 参数：账号/密码
 *      (peter/123)
 * 返回值：true/false
 */
var i = 3;//登陆机会
function logon(acc, pwd){
        // console.log("进入for循环的第"+(3-i)+"轮");
        if (acc == "peter" && pwd == "123") {
            // if (i <= 0) {
                document.getElementById('hint').innerHTML 
                ='登陆成功！';
                location.href = './index.html';//跳转到主页
                
                // break;
            }
            // break;//强制跳出for循环
         else if(i <= 0){//尝试三次
            // if (i <= 0) {
            document.getElementById('hint').innerHTML 
            ='3次登陆失败！';
            // window.reload();
            }
            else{//三次以内验证失败
            i -= 1;//每次登陆失败，登陆机会减1
            document.getElementById('hint').innerHTML 
            ='账号或密码错误，还剩下'+i+'次机会';
        }
}
